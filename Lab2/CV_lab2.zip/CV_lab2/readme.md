# Medical Imaging Portfolio - Lab 02

## VS Code setup

Open this folder in VS Code, create a Python virtual environment, install dependencies with `python -m pip install -r requirements.txt`, then run the commands documented in each task README from that task folder.

Keep only the sample files used by the scripts in each `data/` folder. Do not commit full Kaggle datasets. All paths used by the scripts are relative.

The PDF labels the scripts as `.ipynb`; these are equivalent runnable `.py` implementations for VS Code. If a strict submission checker requires the notebook filenames, create a VS Code notebook with the specified name and paste the corresponding script into one code cell.
